package ctxkey

// ENUM(content-length)
//
//go:generate go-enum --values --names --flag --nocase --noprefix
type ContextKey string
