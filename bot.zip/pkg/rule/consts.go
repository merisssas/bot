package rule

const (
	RuleStorNameChosen     = "CHOSEN"
	RuleDirPathNewForAlbum = "NEW-FOR-ALBUM" // create a new directory for album files
)
