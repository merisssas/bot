package storage

import (
	"errors"
)

var (
	ErrStorageNameEmpty = errors.New("storage name is empty")
)
